#= require insales_theme_settings

#= require layout

#= require index

#= require product

#= require article

#= require cart

#= require checkout-order

#= require collection

#= require compare
