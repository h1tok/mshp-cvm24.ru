#= require jquery.serializeObject.js

#= require jquery.fancybox.min.js

#= require jquery.serializeObject.js

#= require insales.ui.alertify.js

#= require insales.ui.swiper.js

#= require insales.ui.tabs.js

#= require insales.ui.range-slider.js

#= require insales.ui.filter.js

#= require insales.ui.menu.js

#= require insales.ui.forms.js

#= require insales.ui.images.js

#= require RecentlyView.js